package services;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import play.libs.Json;
import twitter4j.*;

import twitter4j.conf.ConfigurationBuilder;

/**
 * @author Nikhil Vijayan
 *
 */
public class TweetService {
	
	/**
	 * This method returns a twitter instance after authentication 
	 * @author Nikhil Vijayan
	 * @return Twitter instance
	 */
	public static Twitter getAuthorization()
	{
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true)
		.setOAuthConsumerKey("iuh1dBIa8bXvOjBSRLpIF7e40")
		.setOAuthConsumerSecret("GAupJH5iFkWycp9r72dN44Tvd0pO14Tkoi4WSsoMt8dSN4GB3E")
		.setOAuthAccessToken("972273228046569473-4GTgsikGCKHXse3RxzTwqSUk23cEhe8")
		.setOAuthAccessTokenSecret("xctHGp1WG295EARuD7uWKuWJuAI9hgPxmDI0IxmK0ZtAI");
		
		TwitterFactory tf = new TwitterFactory(cb.build());
		Twitter twitter = tf.getInstance();
		return twitter;
		
	}
	
	/**
	 * This method queries the tweets, limits them to 10 and returns a future containing a JSON object of tweets
	 * @author Nikhil Vijayan
	 * @param keyword
	 * @return future containing the tweets
	 * @throws TwitterException
	 */
	public static CompletionStage<ArrayNode> getTweets(String keyword) throws TwitterException
	{
		CompletableFuture<ArrayNode> tweetFuture = new CompletableFuture<>();
		Twitter twitterfactory = getAuthorization();
		Query query = new Query(keyword);
		//Limiting the tweets to 10
		query.setCount(10);
		QueryResult queryResult = twitterfactory.search(query);
		List<Status> status = queryResult.getTweets();
			
		//adds each tweet to a JSON array object
		ArrayNode JSONstatus = Json.newArray();
		status.forEach((tweet) -> {
	       	ObjectNode JSONNode = Json.newObject();
	       	JSONNode.put("text", tweet.getText());
	       	JSONNode.put("name", tweet.getUser().getName());
	       	JSONNode.put("screenName", tweet.getUser().getScreenName());
	       	//node.put("geoLocation", tweet.getGeoLocation());
	       	JSONstatus.add(JSONNode);
	    });
		tweetFuture.complete(JSONstatus);
	    return tweetFuture;
	}

}
