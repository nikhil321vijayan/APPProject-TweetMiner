;(function(window) {
	'use strict';
	
	var searchKeyword = document.getElementById("searchkeyword");
	var tweetlist = [];
		
	jQuery('#search-form').submit(function (searchfunc) {
		searchfunc.preventDefault();
        if( searchKeyword.value != '' ){
        	var tweets = "";
        	jQuery.get("http://localhost:9000/tweetminer/" + searchKeyword.value).done(function (allTweets) {
        		tweetlist.concat(allTweets);
        		allTweets.forEach(function (eachTweet) {
        			tweets += "<p>=> "; 
        			tweets += "<b>" + eachTweet.screenName+ " ("+ eachTweet.name+ ") :</b> " + "\"" + eachTweet.text + "\"";
        			tweets += "</p>";
        			});
        		tweets += "<hr>";
                jQuery(".display-tweets").append(tweets);
               });
        }
	});
})(window);
        